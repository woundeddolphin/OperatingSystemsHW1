OperatingSystems HW
===================
University of Portland CS 446 Nuxoll

This repo contains a basic SOS for the entirety of University of Portlands OS class

The commits are generally organized by step in homework assignments

Just copy the getFairProcess() method into the SOS.java file 
and then replace the method that calls get a process in schedulenewprocess() 
with a call to getFairProcess() MAKE SURE VERBOSE MODE IS ON!
